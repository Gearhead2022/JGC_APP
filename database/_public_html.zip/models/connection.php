<?php

class Connection{
	public function connect(){
		$link = new PDO("mysql:host=localhost;dbname=u260564888_emb_appform", "u260564888_jgc", "JGC_app2023");

		$link -> exec("set names utf8");
		return $link;
	}
}