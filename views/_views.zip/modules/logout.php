<?php 
session_destroy();
echo"<script>window.location.href ='login'</script>";