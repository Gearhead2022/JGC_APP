<?php
if (function_exists('exec')) {
    echo 'Composer is installed!';
} else {
    echo 'Composer is not installed!';
}
