

<style>
  .modal-content {
    width: 1000px;
   
} 

</style>
<div class="clearfix"></div>
  
<div class="content-wrapper">
   <div class="container-fluid">
     <div class="row pt-2 pb-2">
        <div class="col-sm-12">
          <h4 class="page-title">PAST DUE COLLECTION</h4>
        </div>
     </div>
      <div class="row">
        <div class="col-lg-12">
        
          <div class="card">
            <div class="card-header float-sm-right">
            <div class="row">
                    <div class="col-sm-1.5 ml-4 form-group">
                        <button type="button" class="btn btn-transparent border border-white text-white btn-round waves-effect waves-light m-1" onClick="location.href='branchPDRColl'"><i class="fa fa-arrow-left"></i> <span>&nbsp;BACK</span> </button>
                    </div>   
                </div>
              <div class="row">
            </div>            
            <div class="card-body">
              <div class="table-responsive">
              <table id="default-datatable" class="table table-bordered table-hover table-striped pastdueListTable">
                <thead>
                <tr>
                  <th>Action</th>
                  <th>ACCOUNT NUMBER</th>
                  <th>NAME</th>
                  <th>TYPE</th>
                  <th>CLASS</th>
                  <th>BANK</th>
                  <th>ENDORSED</th>
                  <th>BRANCH</th>
                </tr>
                </thead>
              </table>
            </div>
            </div>
          </div>
        </div>
                
      </div>    <!-- row -->
    

</div>

    <div class="overlay toggle-menu"></div>


  </div>        <!-- container-fluid -->
</div>          <!-- content-wrapper -->




  
