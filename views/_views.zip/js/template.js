/*====================================
=            sidebar menu            =
====================================*/

$('.sidebar-menu').tree();

/*=====  End of sidebar menu  ======*/


/*=================================
=            datatable            =
=================================*/

$('.tables').dataTable();

/*=====  End of datatable  ======*/

/*=============================================
 //iCheck for checkbox and radio inputs
=============================================*/

$('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
  checkboxClass: 'icheckbox_minimal-blue',
  radioClass   : 'iradio_minimal-blue'
})



/*=================================
=            inputmask            =
=================================*/

//Datemask dd/mm/yyyy
$('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
//Datemask2 mm/dd/yyyy
$('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
//Money Euro
$('[data-mask]').inputmask()


/*=============================================
FIXING HIDDEN BUTTONS IN THE BACKEND	
=============================================*/

// if(window.matchMedia("(max-width:767px)").matches){
	
// 	$("body").removeClass('sidebar-collapse');

// }else{

// 	$("body").addClass('sidebar-collapse');
// }

$("#btn_mode").on("click", function(){
  alert('naclikc');
})

$(document).ready(function(){
 $('#datepicker').datepicker(); 
});


