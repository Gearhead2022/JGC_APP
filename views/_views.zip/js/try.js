$("#try_dl").on("click", function(){

    window.location = "email/download.php";
  })